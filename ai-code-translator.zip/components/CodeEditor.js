import React from 'react';

export default function CodeEditor({ value, onChange, placeholder }) {
  return (
    <textarea
      className="w-full h-48 p-3 rounded-md border focus:outline-none focus:ring-2 focus:ring-indigo-400 font-mono text-sm"
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
    />
  );
}

/**
 * Firebase init - placeholder
 * Replace the config values with your Firebase project's values.
 */
import { initializeApp, getApps } from "firebase/app";

let firebaseApp = null;

export function initFirebase() {
  if (!getApps().length) {
    const config = {
      apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "",
      authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "",
      projectId: process.env.FIREBASE_PROJECT_ID || "",
    };
    firebaseApp = initializeApp(config);
  }
  return firebaseApp;
}

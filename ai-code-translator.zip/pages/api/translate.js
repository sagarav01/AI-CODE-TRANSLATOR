import { translateWithGemini } from '../../utils/gemini';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }
  const { sourceLang, targetLang, code } = req.body || {};
  if (!sourceLang || !targetLang || !code) {
    return res.status(400).json({ error: 'sourceLang, targetLang and code are required' });
  }

  try {
    const result = await translateWithGemini({ sourceLang, targetLang, code });
    if (!result.success) {
      return res.status(500).json({ error: result.error || 'translation failed', raw: result.raw });
    }
    return res.status(200).json({ translatedCode: result.translatedCode, raw: result.raw });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}

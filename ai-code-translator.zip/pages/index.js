import Head from 'next/head';
import { useState } from 'react';
import CodeEditor from '../components/CodeEditor';
import axios from 'axios';

export default function Home() {
  const [sourceLang, setSourceLang] = useState('Python');
  const [targetLang, setTargetLang] = useState('JavaScript');
  const [inputCode, setInputCode] = useState(`# Write code here`);
  const [outputCode, setOutputCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const languages = ['Python', 'JavaScript', 'TypeScript', 'Java', 'Go', 'C++', 'C#', 'Ruby'];

  async function handleTranslate() {
    setError('');
    setLoading(true);
    setOutputCode('');
    try {
      const resp = await axios.post('/api/translate', {
        sourceLang, targetLang, code: inputCode
      });
      setOutputCode(resp.data.translatedCode || '// No translation returned');
    } catch (err) {
      setError(err.response?.data?.error || err.message || 'Unknown error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <Head>
        <title>AI Code Translator</title>
      </Head>
      <main className="max-w-4xl mx-auto p-6">
        <h1 className="text-2xl font-bold mb-4">AI Code Translator</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <select value={sourceLang} onChange={e => setSourceLang(e.target.value)} className="p-2 rounded-md border">
            {languages.map(l => <option key={l} value={l}>{l}</option>)}
          </select>

          <select value={targetLang} onChange={e => setTargetLang(e.target.value)} className="p-2 rounded-md border">
            {languages.map(l => <option key={l} value={l}>{l}</option>)}
          </select>

          <button onClick={handleTranslate} disabled={loading} className="p-2 rounded-md bg-indigo-600 text-white">
            {loading ? 'Translating...' : 'Translate'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h2 className="font-semibold mb-2">Input</h2>
            <CodeEditor value={inputCode} onChange={setInputCode} placeholder="Paste code here..." />
          </div>
          <div>
            <h2 className="font-semibold mb-2">Output</h2>
            <CodeEditor value={outputCode} onChange={setOutputCode} placeholder="Translated code will appear here..." />
          </div>
        </div>

        {error && <p className="text-red-600 mt-4">Error: {error}</p>}
      </main>
    </div>
  );
}
